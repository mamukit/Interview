package day4;

import java.util.Arrays;

public class SortingArray {

	public static void main(String[] args) {
		
		/*int data[]= {100,10,15,5,20,25,150};
		
		
		System.out.println("Before sorting.............");
		for(int x:data)
		{
			System.out.println(x);
		}
		
		Arrays.sort(data); //sorted
		
		System.out.println("After sorting.............");
		for(int x:data)
		{
			System.out.println(x);
		}*/
		
		String data[]= {"z","a","x"};
		
		Arrays.sort(data);
		
		for(String i:data)
		{
			System.out.println(i);
		}

	}

}
