package day3;

public class EvenOrOddNumber {

	public static void main(String[] args) {
		
		int num=15;
		
		if(num%2 == 0)
		{
			System.out.println("Number is Even number");
		}
		else
		{
			System.out.println("Number is Odd number");
		}

	}

}
