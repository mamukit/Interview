package day3;

public class WhileLoopDemo {

	public static void main(String[] args) {
	
		//1,2,3,4,5,6,7,8,9,10
		
		int i=1;
		
		while(i<=10) //1 2 34 5 6 7 8 9 
		{
		System.out.println(i); //1 2 3 4 5 6 7 8 9 10
		i++;   //i=i+1;
		}
		
		//2,4,6,8,10 even numbers
		
		//i=2;
		/*while(i<=20)
		{
			System.out.println(i);//2,4 6, 8 10..20
			i=i+2;
		}*/
		
		//10, 9,8,7,6,5,4,3,2,1,0
			
		//i=10;
		
		/*while(i>0)
		{
			System.out.println(i);//10 9 8....1
			i--;
		}*/
		
		
	}

}
