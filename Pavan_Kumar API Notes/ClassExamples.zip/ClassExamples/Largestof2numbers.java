package day3;

public class Largestof2numbers {

	public static void main(String[] args) {
		
		int x=200;
		int y=100;
		
		if(x>y)
		{
			System.out.println("x is largest number"+x);
		}
		else
		{
			System.out.println("y is largest number"+y);
		}

	}

}
