package day3;

public class DoWhileLoopDemo {

	public static void main(String[] args) {
	
		//1...10
		
		int i=100;
		
		do
		{
		System.out.println(i);
		i++;
		}while(i<=10);
		
		

	}

}
