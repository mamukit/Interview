package day3;

public class IfElseConditionDemo {

	public static void main(String[] args) {
	
		int person_age=15;

		
		if(person_age>=18)
		{
			System.out.println("Eligible for vote");
		}
		else
		{
			System.out.println("Not Eligible for vote");
		}
	}

}
