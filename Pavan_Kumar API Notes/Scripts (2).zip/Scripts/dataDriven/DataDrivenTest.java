package dataDriven;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class DataDrivenTest {

	@Test
	public void createRecord() throws IOException
	{
	
	String path=System.getProperty("user.dir")+"//src/test/java/dataDriven/TestData.xlsx";
	
	RestAssured.baseURI = "http://localhost:8085";
	RequestSpecification request = RestAssured.given();

	int rowcount=XLUtils.getRowCount(path, "Sheet1");
	System.out.println(rowcount);
	
	for(int i=1;i<=rowcount;i++)
	{
		JSONObject requestParams = new JSONObject();
		requestParams.put("id", XLUtils.getCellData(path, "Sheet1",i,0)); // Cast
		requestParams.put("firstName", XLUtils.getCellData(path, "Sheet1",i,1));
		requestParams.put("lastName", XLUtils.getCellData(path, "Sheet1",i,2));
		requestParams.put("email", XLUtils.getCellData(path, "Sheet1",i,3));
		requestParams.put("programme", XLUtils.getCellData(path, "Sheet1",i,4));
		
		List<String> courses = new ArrayList<String>();
		courses.add(XLUtils.getCellData(path, "Sheet1",i,5));
		courses.add(XLUtils.getCellData(path, "Sheet1",i,6));
		 
		requestParams.put("courses", courses);

		// Add a header stating the Request body is a JSON
		request.header("Content-Type", "application/json");

		// Add the Json to the body of the request
		request.body(requestParams.toJSONString());

		// Post the request and check the response
		//Response response = request.post("/student");   // HTTP Post method
		Response response=request.request(Method.POST,"/student");
						
				
		System.out.println("Response body: " + response.body().asString());

		// Validate the Response status code
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, 201); // 201- Created

		// Validate the Response success code
		String successCode = response.jsonPath().get("msg");
		Assert.assertEquals(successCode, "Student added");
	}
	}
	
	
}
