package studentAPItests;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC3_PUT_UpdateRecord {

	@Test
	public void updateRecord()
	{
		RestAssured.baseURI = "http://localhost:8085";
		RequestSpecification request = RestAssured.given();

		// JSONObject is a class that represents a simple JSON. We can add Key -
		// Value pairs using the put method

		JSONObject requestParams = new JSONObject();
		
		requestParams.put("id", "101"); // Cast
		requestParams.put("firstName", "Pavan");
		requestParams.put("lastName", "Kumar");
		requestParams.put("email", "abcdefrg@gmail.com");
		requestParams.put("programme", "Trainer");
		
		List<String> courses = new ArrayList<String>();
		courses.add("Java");
		courses.add("Selenium");
		courses.add("BigData");
		requestParams.put("courses", courses);

		// Add a header stating the Request body is a JSON
		request.header("Content-Type", "application/json");

		// Add the Json to the body of the request
		request.body(requestParams.toJSONString());  // aDDING REQUEST PAYLOAD TO REQUEST BODY

		// Post the request and check the response
		  //Response response = request.put("/student/101");  // HTTP PUT method
			Response response=request.request(Method.PUT,"/student/101");
			
		System.out.println("Response body: " + response.body().asString());

		// Validate the Response status code
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, 200); // 200- Ok

		// Validate the Response success code
		String successCode = response.jsonPath().get("msg");
		Assert.assertEquals(successCode, "Student Updated");
	}
}
