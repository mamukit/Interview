package WebservicesTestcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class TC4_ValidatingHeaders_GoogleAPI {
	
	@Test
	public void getHeadersGoolge()
	{
		RestAssured.baseURI="https://maps.googleapis.com";
		
		RequestSpecification req=RestAssured.given();
		
		Response res=req.request(Method.GET,"/maps/api/place/nearbysearch/xml?location=-33.8670522,151.1957362&radius=1500&type=supermarket&key=AIzaSyAM7Dk24PNdbuyBoDwJfSFCzOmkNHxqays");
		
		//Capture headers and validate
		
		String contentType=res.header("Content-Type");
		System.out.println(contentType);
		
		Assert.assertEquals("application/xml; charset=UTF-8", contentType);
		
		
		String contentEncoding=res.header("Content-Encoding");
		System.out.println(contentEncoding);
		Assert.assertEquals(contentEncoding, "gzip");
		
		
	}
	
}
