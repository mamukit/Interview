package WebservicesTestcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC3_GET_ListUsers {

	@Test
	public void listUsers()
	{
	
		RestAssured.baseURI="https://reqres.in";
		RequestSpecification req=RestAssured.given();
		
		Response res=req.request(Method.GET,"/api/users?page=2");
		
		String responseBody=res.getBody().asString();
		
		//validation
		
		//status code
		int statusCode=res.getStatusCode();
			System.out.println(statusCode);
		Assert.assertEquals(statusCode,200);
		
		//status Line
		String  statusLine=res.getStatusLine();
		Assert.assertEquals(statusLine,"HTTP/1.1 200 OK");
		
		
	}
	
}
