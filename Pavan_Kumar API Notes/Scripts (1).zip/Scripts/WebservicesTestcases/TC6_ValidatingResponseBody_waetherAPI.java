package WebservicesTestcases;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import junit.framework.Assert;

public class TC6_ValidatingResponseBody_waetherAPI {

	@Test
	public void validatingResponseBody()
	{
		RestAssured.baseURI="http://restapi.demoqa.com/utilities/weather/city";
		RequestSpecification req=RestAssured.given();
		
		Response res=req.request(Method.GET,"/Delhi");
		
		ResponseBody body=res.getBody();
		
		String bodyasString=body.asString();
		
		Assert.assertEquals(bodyasString.contains("Delhi"),true);		//Validates wheathere Hyderabad is present in response body or not
		
		
	}
	
}
