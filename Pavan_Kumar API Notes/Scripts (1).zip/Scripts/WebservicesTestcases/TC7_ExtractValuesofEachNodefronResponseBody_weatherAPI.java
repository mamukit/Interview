package WebservicesTestcases;

import org.junit.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC7_ExtractValuesofEachNodefronResponseBody_weatherAPI {
	
	@Test
	public void validatingResponseBody()
	{
		RestAssured.baseURI="http://restapi.demoqa.com/utilities/weather/city";
		RequestSpecification req=RestAssured.given();
		
		Response res=req.request(Method.GET,"/Delhi");
		
		JsonPath jsonpathEvaluator=res.jsonPath();
		
		System.out.println(jsonpathEvaluator.get("City"));
				Assert.assertEquals(jsonpathEvaluator.get("City"),"Delhi");
		
		System.out.println(jsonpathEvaluator.get("Temperature"));
		System.out.println(jsonpathEvaluator.get("WeatherDescription"));
		System.out.println(jsonpathEvaluator.get("WindSpeed"));
		
		
	}

}
